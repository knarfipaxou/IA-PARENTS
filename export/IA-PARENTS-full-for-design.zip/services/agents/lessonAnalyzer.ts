import { askClaude, extractJSON, type EcheanceLite, type LessonLite } from '../ai';
import { salvageArray } from '../../lib/jsonSalvage';
import { buildProgramContext } from '../education/programmes';
import type { Child } from '../../data/mock';
import { validateLessonAnalysis, type LessonAnalysis2 } from './types';

export const LESSON_ANALYZER_PROMPT_VERSION = 'lesson-analyzer/v1';

const SYSTEM = `Tu es lesson-analyzer, un agent d'analyse pédagogique. Tu analyses INTÉGRALEMENT une leçon avant toute génération.
Tu détectes : définitions, vocabulaire, dates, périodes, personnages, lieux, chiffres importants, formules, règles, propriétés, méthodes, événements, citations ou devises, éléments signalés « à retenir », contenus des tableaux/cartes/schémas/légendes, objectifs annoncés, conclusion.
Tu détectes aussi les problèmes : pages manquantes, phrases interrompues, définitions coupées, contradictions, contenu illisible.
Tu ne crées PAS de questions, tu ne produis PAS de devoir, tu n'inventes RIEN, tu ne complètes JAMAIS la leçon avec des connaissances extérieures.
Tu réponds UNIQUEMENT en JSON valide, sans markdown ni texte autour.`;

/**
 * Agent 1 — lesson-analyzer : construit la carte structurée des connaissances
 * à partir des leçons rattachées à l'échéance. Sortie validée par schéma.
 */
export async function runLessonAnalyzer(
  echeance: EcheanceLite,
  lessons: LessonLite[],
  child: Child,
): Promise<LessonAnalysis2> {
  const lessonsBlock = lessons
    .map((l, i) => {
      const head = `Leçon ${i + 1} — ${l.matiere} : ${l.titre}\nNotions relevées: ${l.notions.join(', ')}`;
      // transcription complète si disponible (leçons scannées récemment), sinon résumé
      return l.texte
        ? `${head}\nCONTENU COMPLET :\n${l.texte.slice(0, 9000)}`
        : `${head}\nRésumé (transcription complète indisponible — signale-le dans detectedUncertainties) : ${l.resume}`;
    })
    .join('\n\n');
  const text = await askClaude({
    system: SYSTEM,
    user: `Élève : ${child.name}, classe ${child.classe}, ${child.age} ans.
Il prépare : ${echeance.type} de ${echeance.subj} (${echeance.date})${echeance.consigne ? ` — consigne du professeur : ${echeance.consigne}` : ''}.
${buildProgramContext(lessons.map((l) => l.programme))}
Voici la ou les leçons à analyser INTÉGRALEMENT :
${lessonsBlock}

Découpe TOUT le contenu en connaissances ATOMIQUES (une idée testable par entrée). Ne regroupe pas plusieurs faits distincts dans une même entrée. Chaque date, chaque définition, chaque personnage, chaque chiffre important est une entrée séparée.
{"status": "complete|probably_complete|incomplete|illegible|contradictory", "statusDetail": "détail si problème (page manquante, phrase coupée, contradiction), sinon omis", "knowledge": [{"knowledgeId": "DEF-001", "type": "definition|vocabulaire|date|periode|personnage|lieu|chiffre|formule|regle|propriete|methode|evenement|citation|autre", "label": "énoncé court de la connaissance", "content": "contenu exact tiré de la leçon, en une phrase", "importance": "essential|important|secondary", "cognitiveLevel": "remember|understand|apply|transfer"}], "detectedUncertainties": ["incertitude à signaler au parent"]}
RÈGLES :
- SOIS CONCIS : "label" et "content" tiennent chacun en une phrase courte. Pas d'extraits de la leçon, pas de champ supplémentaire. JSON compact.
- Maximum 45 connaissances : couvre d'abord TOUTES les essential, puis les important ; les secondary seulement s'il reste de la place.
- Chaque knowledgeId est unique (préfixe par type : DEF-, VOC-, FCT-, PER-, LIEU-, CHI-, FOR-, REG-, MET-, EVT-…).
- "importance": essential = explicitement central ou indispensable ; important = utile à la note ; secondary = détail.
- "cognitiveLevel": remember = à restituer par cœur ; understand = à expliquer ; apply = à mettre en œuvre dans un exercice ; transfer = à mobiliser dans un problème nouveau.
- Si un champ n'est pas lisible ou absent : ne l'invente pas, signale-le dans detectedUncertainties.
- Si plus de 40 % du contenu est illisible ou manquant : status incomplete ou illegible.`,
    maxTokens: 6144,
  });
  try {
    return validateLessonAnalysis(extractJSON(text));
  } catch {
    // réponse tronquée : on récupère les connaissances complètes + le statut
    const knowledge = salvageArray(text, 'knowledge');
    const statusMatch = text.match(/"status"\s*:\s*"([a-z_]+)"/);
    if (knowledge.length === 0) throw new Error("L'IA a renvoyé un format inattendu. Réessayez.");
    return validateLessonAnalysis({
      status: statusMatch?.[1] ?? 'probably_complete',
      knowledge,
      detectedUncertainties: ["Analyse partiellement tronquée : certaines connaissances de fin de leçon peuvent manquer."],
    });
  }
}
